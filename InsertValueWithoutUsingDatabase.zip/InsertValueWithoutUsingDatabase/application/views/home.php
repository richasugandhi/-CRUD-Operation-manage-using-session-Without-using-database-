<?php 
$K=$this->session->userdata('mydata');
$sessCount = count($K);
?>
<html>
<head>
<title>CRUD</title>
<script src="https://ajax.aspnetcdn.com/aja/jQuery/jquery-3.2.1.min.js"></script>
</head>
<body>
<h2 style="text-align:center;">Welcome to list</h2>
<div style="text-align:center;">
<div class="add-from">
<form action="" method="post" enctype="multipart/form-data" id="AddForm">
 <table class="MyTable" style="text-align:center;width:100%;"> 
 <tr>
     <td><input type="text" name="fname" id="fname" placeholder="Your First Name" required>
     <input type="text" name="lname" id="lname" placeholder="Your Lname Name" required>
     <input type="hidden" name="action" id="action" value="Add" data-id="">
     <input type="submit" name="Add" class="AddNewBtn" value="Add"></td>     
 </tr>
 <tr><td><p class="alert-msg"></p></td></tr>
</table>
</form>
</div>
<div class="Tablediv">
<table class="MyTable" style="text-align:center;width:100%;" border="1">
 <tr>
     <th>Sr no</th>
     <th>Fname</th>
     <th>Lname</th>
     <th>Action</th>
 </tr>
 <?php if(!empty($K)){ $i=1;foreach($K as $key=>$Data){ ?>
 <tr id="<?php echo $key;?>">
     <td><?php echo $i;?></td>
     <td class="td_fname"><?php echo $Data['fname'];?></td>
     <td class="td_fname"><?php echo $Data['lname'];?></td>
     <td>
       <a href="#" data-sessid="<?php echo $key;?>" class="delete">Delete</a>&nbsp;&nbsp;
       <a href="#" data-sessid="<?php echo $key;?>" class="edit">Edit</a>
     </td>
 </tr>
<?php $i++;}} else{
	
	echo '<tr><td colspan="4">No record found in session</td></tr>';
	
	}?>  
</table>
</div>

</div>

<script>
$(document).on('click', '.edit', function(e) { e.preventDefault();	
//$('.edit').click(function(e){e.preventDefault();
   var id= $(this).attr('data-sessid');
   $.post("<?php echo base_url('CRUD/GetRowData');?>",
		   {id:id},
		   function(data){
		   var res = data.split("/");
		   $("#fname").val(res[0]);
		   $("#lname").val(res[1]); 
		   $("#action").attr('value','Update');
		   $("#action").attr('data-id',id);
		   $(".AddNewBtn").attr('value','Update');
});   

});

</script>

<script>
//$('.AddNewBtn').click(function(e){e.preventDefault(); 
$(document).on('click', '.AddNewBtn', function(e) { e.preventDefault();											   
  var fname = $("#fname").val();	
  var lname = $("#lname").val();
  var action =$("#action").attr('data-id');  //alert(action);
  if((fname!='') && (lname!=''))
  {
	   var form_val = $('#AddForm').serialize();
	   $.post("<?php echo base_url('CRUD/Add');?>",
		   {form_val:form_val,action:action},
		   function(data){   //alert(data);return false;
		    $('.Tablediv').html(data);
			$('#MyTable').append('<tr><td>test 2</td><td>test 2</td><td>test 2</td></tr>'); 
			$('.alert-msg').css('color','#0C0');
			$('.alert-msg').html('Record Added Successfully');
			$('.alert-msg').fadeOut(3000);
			$("#action").attr('value','Add');
			$("#action").attr('data-id','');
			$(".AddNewBtn").attr('value','Add');
			$('#AddForm')[0].reset();
		});
	  
	  
	  
  }else
  {
	  $('.alert-msg').css('color','#F00');
	  $('.alert-msg').html('first name & last name should not be empty....');
	  $('.alert-msg').fadeOut(3000);
  }
												   
});

</script>

<script>
//$('.delete').click(function(e){e.preventDefault();
$(document).on('click', '.delete', function(e) { e.preventDefault();												
  var id= $(this).attr('data-sessid');
  $.post("<?php echo base_url('CRUD/Remove');?>",
		   {id:id},
		   function(data){   //alert(data);return false; 
		   $('.Tablediv').html(data);		   
		    ('.alert-msg').css('color','#0C0');
				$('.alert-msg').html('Record Removed Successfully');
				$('.alert-msg').fadeOut(3000);
				$('#AddForm')[0].reset();
			 
		});
});
</script>

</body>
</html>