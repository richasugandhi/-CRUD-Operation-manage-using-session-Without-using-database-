<?php
$K=$this->session->userdata('mydata');
?>
<table class="MyTable" style="text-align:center;width:100%;" border="1">
 <tr>
     <th>Sr no</th>
     <th>Fname</th>
     <th>Lname</th>
     <th>Action</th>
 </tr>
 <?php if(!empty($K)){ $i=1;foreach($K as $key=>$Data){ ?>
 <tr id="<?php echo $key;?>">
     <td><?php echo $i;?></td>
     <td class="td_fname"><?php echo $Data['fname'];?></td>
     <td class="td_fname"><?php echo $Data['lname'];?></td>
     <td>
       <a href="#" data-sessid="<?php echo $key;?>" class="delete">Delete</a>&nbsp;&nbsp;
       <a href="#" data-sessid="<?php echo $key;?>" class="edit">Edit</a>
     </td>
 </tr>
<?php $i++;}} else{
	
	echo '<tr><td colspan="4">No record found in session</td></tr>';
	
	}?>  
</table>