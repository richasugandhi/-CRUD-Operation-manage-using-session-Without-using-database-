<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CRUD extends CI_Controller {
	
	function __construct() {
        parent::__construct();
		//$this->session->userdata('mydata')
		$this->Sess=$this->session->userdata('mydata');
    }
	
	public function index()
	{				
		$this->load->view('home');
	}
	
	public function Add()
	{		
	if($this->input->post('form_val'))
	{
		parse_str($this->input->post('form_val'),$myArray);
		$id=$this->input->post('action');
		if(!empty($myArray))
		{
		  if($myArray['action']=='Add')
		  {		
			  $this->Sess[]=$myArray;		  
			  $this->session->set_userdata('mydata',$this->Sess);
			  $this->load->view('ajaxview');
		  }else
		  {
			    foreach($this->Sess as $key => $D)
				{
					if($key == $id){ 
					  $this->Sess[$id]['fname']=$myArray['fname'];
					  $this->Sess[$id]['lname']=$myArray['lname'];
					  $this->session->set_userdata('mydata',$this->Sess);						  
					  $this->load->view('ajaxview');					  
					  
					}			
				}
			  			  
		  }		  
		}else
		{}
	}else
	{
		echo 'Something is going wring';die;
	}
				
	}
	public function Remove()
	{
		$id = $this->input->post('id');
		$S=$this->Sess;
		foreach($S as $key => $D)
		{
			if($key == $id){ unset($S[$id]); }			
		}
		$this->session->set_userdata('mydata',$S);
		$this->load->view('ajaxview');
		
		
	}
	public function GetRowData()
	{ 
	    $id = $this->input->post('id');
		$S=$this->Sess;
		foreach($S as $key => $D)
		{
			if($key == $id){ 
			 echo $D['fname'].'/'.$D['lname'];
			
			}			
		}
		$this->session->set_userdata('mydata',$S);
	}
	public function UpdateData()
	{ 
	   
		
	}
	
	
	
}
